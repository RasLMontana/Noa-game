"""Telegram-бот, который открывает игру про Ноа как Mini App."""
import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    BotCommand,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    MenuButtonWebApp,
    Message,
    WebAppInfo,
)

TOKEN = os.environ["BOT_TOKEN"]      # токен от @BotFather
WEBAPP_URL = os.environ["WEBAPP_URL"]  # https-адрес, где лежит index.html

dp = Dispatcher()


def play_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⚔️ Играть", web_app=WebAppInfo(url=WEBAPP_URL))]
        ]
    )


@dp.message(CommandStart())
async def start(message: Message) -> None:
    name = message.from_user.first_name if message.from_user else "путник"
    await message.answer(
        f"Привет, {name}!\n\n"
        "Ты очнулся на берегу рядом с погасшим маяком и ничего не помнишь. "
        "Выполняй задания и походы, одевай Ноа, побеждай боссов и собирай осколки Маяка.\n\n"
        "Прогресс сохраняется в твоём аккаунте Telegram.",
        reply_markup=play_keyboard(),
    )


@dp.message(Command("play"))
async def play(message: Message) -> None:
    await message.answer("Открываю игру:", reply_markup=play_keyboard())


@dp.message(Command("help"))
async def help_cmd(message: Message) -> None:
    await message.answer(
        "Как играть:\n"
        "• Дела и походы дают опыт, монеты и осколки уникальных предметов.\n"
        "• В лавке покупай броню, оружие и зелья энергии.\n"
        "• В кузнице прокачивай предметы.\n"
        "• Боссы открываются на 2, 4, 6 и 8 уровнях.\n\n"
        "Команда /play открывает игру.",
        reply_markup=play_keyboard(),
    )


async def main() -> None:
    logging.basicConfig(level=logging.INFO)
    bot = Bot(token=TOKEN)
    await bot.set_my_commands(
        [
            BotCommand(command="play", description="Открыть игру"),
            BotCommand(command="help", description="Как играть"),
        ]
    )
    await bot.set_chat_menu_button(
        menu_button=MenuButtonWebApp(text="Играть", web_app=WebAppInfo(url=WEBAPP_URL))
    )
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
